# Script to cleanup istio-knative-kserve deployment

if [[ -z ${HELMCHART_LOCATION} ]]; then
  echo -e "\nPlease specify the helm cart location (HELMCHART_LOCATION)\n"
  exit 1
fi

kubectl -n aizen-infra delete -f https://github.com/kubernetes-sigs/gateway-api/releases/download/v1.3.0/standard-install.yaml
helm -n aizen-infra delete kserve kserve-crd cert-manager
kubectl -n aizen-infra delete -f $HELMCHART_LOCATION/aizen/charts/infra/charts/istio-knative-kserve/serving-core.yaml
kubectl delete -f $HELMCHART_LOCATION/aizen/charts/infra/charts/istio-knative-kserve/net-istio.yaml
kubectl -n aizen-infra apply -f https://github.com/knative/serving/releases/download/knative-v1.17.0/serving-crds.yaml 2>&1  >/dev/null
helm -n istio-system delete istio-ingress istiod istio-base
kubectl delete crd \
  wasmplugins.extensions.istio.io \
  authorizationpolicies.security.istio.io \
  peerauthentications.security.istio.io \
  requestauthentications.security.istio.io \
  telemetries.telemetry.istio.io \
  destinationrules.networking.istio.io \
  envoyfilters.networking.istio.io \
  gateways.networking.istio.io \
  proxyconfigs.networking.istio.io \
  serviceentries.networking.istio.io \
  sidecars.networking.istio.io \
  virtualservices.networking.istio.io \
  workloadentries.networking.istio.io 2>&1 >/dev/null
