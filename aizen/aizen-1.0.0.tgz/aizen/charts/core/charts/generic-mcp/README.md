# Generic MCP Helm Subchart

Subchart of **aizen** / **workflow** core for dynamic MCP server deployment (npx / uvx / docker).

Shipped inside:

- `aizen-helmcharts` (`package-helm-charts.sh`)
- `aizen-workflow-helmcharts` (`package-workflow-helmcharts.sh`)

## What it provides

- **RBAC** — `aizen-admin` can manage Deployments, Services, Secrets, Ingresses, HTTPRoutes for per-project MCP pods
- **ConfigMap** — `MCP_RUNNER_IMAGE` and gateway settings
- **Optional preload Job** — `generic-mcp.preload_runner_image: true`

## Enable

```yaml
generic-mcp:
  enabled: true
```

## Build runner image

```bash
./package-generic-mcp.sh
```
