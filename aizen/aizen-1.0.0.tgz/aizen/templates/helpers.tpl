{{/*
Common labels
*/}}

{{- define "common.labels" -}} 
app.kubernetes.io/name: {{ .Chart.Name }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
service_name: {{ .Values.name }}-service
project_name: ""
job_name: ""
{{- end -}}

