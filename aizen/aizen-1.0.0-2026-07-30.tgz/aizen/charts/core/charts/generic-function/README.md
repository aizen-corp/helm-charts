# Generic Function Helm Subchart

Subchart of **aizen** / **workflow** core for the Function Registry (Python / Node.js user functions).

Shipped inside:

- `aizen-helmcharts` (`package-helm-charts.sh`)
- `aizen-workflow-helmcharts` (`package-workflow-helmcharts.sh`)

## What it provides

- **RBAC** — `aizen-admin` can manage Deployments, Services, NetworkPolicies for per-project function runner pods
- **ConfigMap** — `FUNCTION_RUNNER_IMAGE` for the GUI backend
- **Optional preload Job** — `generic-function.preload_runner_image: true`

## Enable

```yaml
generic-function:
  enabled: true
```

## Build runner image

| `BUILD_TYPE` | Image |
|--------------|--------|
| `developer` (default in `k8spackage.sh`) | `aizen-generic-function-runner-${USER}:1.0.0` |
| `release` | `aizen-generic-function-runner:1.0.0` |

```bash
./package-generic-function.sh
```

Helm packaging (`dev_helm_charts.sh add_tag`) rewrites `generic-function` chart `image:` to the
developer-suffixed name when that image exists in the registry.
