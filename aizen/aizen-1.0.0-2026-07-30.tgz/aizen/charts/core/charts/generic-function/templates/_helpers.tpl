{{/*
Runner image reference for FunctionRuntimeManager (shared per-project runner).
*/}}
{{- define "generic-function.runnerImage" -}}
{{- $registry := .Values.global.image_registry -}}
{{- $image := .Values.image -}}
{{- $tag := .Values.image_tag | default .Values.global.image_tag -}}
{{- printf "%s/%s:%s" $registry $image $tag -}}
{{- end }}
