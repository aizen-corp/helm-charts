# Generic MCP Helm Subchart

Subchart of **aizen** / **workflow** core for dynamic MCP server deployment (npx / uvx / docker).

Shipped inside:

- `aizen-helmcharts` (`package-helm-charts.sh`)
- `aizen-workflow-helmcharts` (`package-workflow-helmcharts.sh`)

## What it provides

- **RBAC** — `aizen-admin` can manage Deployments, Services, Secrets, Ingresses, HTTPRoutes for per-project MCP pods
- **ConfigMap** — `MCP_RUNNER_IMAGE` and gateway settings
- **Optional preload Job** — `generic-mcp.preload_runner_image: true`

## Enable

```yaml
generic-mcp:
  enabled: true
```

## Build runner image

Naming follows the same rule as other Aizen images (`k8senv.sh` / `BUILD_TYPE`):

| `BUILD_TYPE` | Image |
|--------------|--------|
| `developer` (default in `k8spackage.sh`) | `aizen-generic-mcp-runner-${USER}:1.0.0` |
| `release` | `aizen-generic-mcp-runner:1.0.0` |

```bash
# Developer (default)
./package-generic-mcp.sh

# Release (elevoai only)
export BUILD_TYPE=release
./package-generic-mcp.sh
```

Helm packaging (`dev_helm_charts.sh add_tag`) rewrites `generic-mcp` chart `image:` to the
developer-suffixed name when that image exists in the registry.
