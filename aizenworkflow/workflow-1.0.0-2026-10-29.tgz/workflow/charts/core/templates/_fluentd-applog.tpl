{{/*
  Shared applog fluentd sidecar (core parent chart — visible to core subcharts).

  {{- include "aizen.fluentdApplogSidecarContainer" (dict "root" . "indexName" (printf "%s-service" .Values.name)) | nindent 6 }}
  Add after applog / fluentconfig volumes:
  {{- include "aizen.fluentdApplogVolumes" . | nindent 6 }}
*/}}

{{- define "aizen.fluentd.elasticsearchScheme" -}}
{{- if .Values.global.log.elasticsearch_scheme -}}
{{- .Values.global.log.elasticsearch_scheme -}}
{{- else if .Values.global.secure_https -}}
https
{{- else -}}
http
{{- end -}}
{{- end -}}

{{- define "aizen.fluentd.elasticsearchSslVerify" -}}
{{- if eq true .Values.global.log.elasticsearch_ssl_verify -}}
true
{{- else if .Values.global.log.elasticsearch_scheme | default "" | eq "https" -}}
true
{{- else if .Values.global.secure_https -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{- define "aizen.fluentd.elasticsearchAuthEnabled" -}}
{{- $log := .Values.global.log | default dict -}}
{{- $secret := $log.elasticsearch_password_secret | default dict -}}
{{- if or $log.elasticsearch_user $log.elasticsearch_password $secret.name }}true{{ end -}}
{{- end -}}

{{- define "aizen.fluentd.elasticsearchAuthEnv" -}}
    - name: FLUENT_ELASTICSEARCH_SSL_VERIFY
      value: {{ include "aizen.fluentd.elasticsearchSslVerify" . | quote }}
{{- $log := .Values.global.log | default dict -}}
{{- $espSecret := $log.elasticsearch_password_secret | default dict -}}
{{- with $log.elasticsearch_user }}
    - name: FLUENT_ELASTICSEARCH_USER
      value: {{ . | quote }}
{{- end }}
{{- if $espSecret.name }}
    - name: FLUENT_ELASTICSEARCH_PASSWORD
      valueFrom:
        secretKeyRef:
          name: {{ $espSecret.name }}
          key: {{ default "password" $espSecret.key }}
{{- else if $log.elasticsearch_password }}
    - name: FLUENT_ELASTICSEARCH_PASSWORD
      value: {{ $log.elasticsearch_password | quote }}
{{- end }}
{{- end -}}

{{- define "aizen.fluentd.elasticsearchOutputAuth" -}}
{{- $indent := .indent | default "      " -}}
{{- $root := .root | default . -}}
{{- if include "aizen.fluentd.elasticsearchAuthEnabled" $root }}
{{ $indent }}user "#{ENV['FLUENT_ELASTICSEARCH_USER']}"
{{ $indent }}password "#{ENV['FLUENT_ELASTICSEARCH_PASSWORD']}"
{{- end }}
{{- end -}}

{{- define "aizen.fluentd.fluentUid" -}}
{{- $fuid := .Values.global.log.fluentd_uid -}}
{{- if or $fuid (eq $fuid 0) -}}
{{- $fuid -}}
{{- else if .Values.global.containerSecurityContextEnabled -}}
{{- .Values.global.containerSecurityContext.runAsUser | default 1001 -}}
{{- else -}}
1001
{{- end -}}
{{- end -}}

{{- define "aizen.fluentdApplogSidecarContainer" -}}
{{- $ := .root -}}
{{- $indexName := required "indexName" .indexName -}}
{{- $applogPath := .applogMountPath | default "/opt/aizen/log" -}}
{{- $withSecurity := .withSecurityContext | default true -}}
- name: fluentdapp
  image: {{ $.Values.global.log.fluentd_image }}
  {{- if and $withSecurity $.Values.global.containerSecurityContextEnabled }}
  securityContext:
{{- toYaml $.Values.global.containerSecurityContext | nindent 4 }}
  {{- end }}
  resources:
{{- toYaml $.Values.global.log.fluentd_sidecar.resources | nindent 4 }}
  env:
    - name: FLUENT_ELASTICSEARCH_HOST
      value: {{ $.Values.global.log.elasticsearch_service }}
    - name: FLUENT_ELASTICSEARCH_PORT
      value: "{{ $.Values.global.ports.elastic_search_port }}"
    - name: FLUENT_ELASTICSEARCH_SCHEME
      value: {{ include "aizen.fluentd.elasticsearchScheme" $ | quote }}
    - name: FLUENT_ELASTICSEARCH_SED_DISABLE
      value: "false"
{{ include "aizen.fluentd.elasticsearchAuthEnv" $ | nindent 4 }}
    - name: FLUENT_UID
      value: {{ include "aizen.fluentd.fluentUid" $ | quote }}
    - name: POD_NAMESPACE
      value: {{ $.Release.Namespace }}
    - name: INDEX_NAME
      value: {{ $indexName }}
  volumeMounts:
    - name: applog
      mountPath: {{ $applogPath }}
    - name: fluentdpos
      mountPath: /var/log/fluentd-pos
    - name: fluentconfig
      mountPath: /fluentd/etc/fluent.conf
      subPath: fluent.conf
{{- end -}}

{{- define "aizen.fluentdApplogVolumes" -}}
- name: fluentdpos
  emptyDir: {}
{{- end -}}
